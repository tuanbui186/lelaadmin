@extends('layouts.master')
@section('content')
<!-- start: Content -->
            <div id="content">
               <div class="panel box-shadow-none content-header">
                  <div class="panel-body">
                    <div class="col-md-12">
                        <h3 class="animated fadeInLeft">Payment Configure</h3>
                        <p class="animated fadeInDown">
                        {{ Form::open(array('route'=>array('uppayment',1),'method'=>'PUT', 'class'=> 'form-horizontal')) }}
                        {!! csrf_field() !!}
                          <div class="row">
                            <div class="form-group {{ $errors->has('txtClientId') ? ' has-error' : '' }}">
                              <label class="col-md-3 control-label" for="business_phone_company">CLIENT ID</label>
                              <div class="col-md-9">
                                <input type="text" id="" name="txtClientId" class="form-control input-sm" 
                                value="{!! old('txtClientId',isset($edit) ? $edit->clientId : null) !!}">
                                 @if ($errors->has('txtClientId'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('txtClientId') }}</strong>    
                                    </span>
                                  @endif
                              </div>
                            </div>  
                          </div>
                          <p>
                        <div class="row">
                            <div class="form-group {{ $errors->has('txtclientSecret') ? ' has-error' : '' }}">
                              <label class="col-md-3 control-label" for="business_phone_company">CLIENT SECRET</label>
                              <div class="col-md-9">
                                <input type="text" id="" name="txtclientSecret"  class="form-control input-sm" 
                                value="{!! old('txtclientSecret',isset($edit) ? $edit->clientSecret : null) !!}">
                                 @if ($errors->has('txtclientSecret'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('txtclientSecret') }}</strong>    
                                    </span>
                                  @endif
                              </div>
                            </div>  
                          </div>
                        </p>
                          <div class="row">
                            <div class="form-group {{ $errors->has('txtMode') ? ' has-error' : '' }}">
                              <label class="col-md-3 control-label" for="business_phone_company">MODE</label>
                              <div class="col-md-9">
                                <label class="radio-inline">
                                  <input type="radio" name="txtMode" id="inlineRadio1" value="Sandbox" <?php if ($edit->mode == '0'): ?>checked='checked'<?php endif; ?>/> Sandbox
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="txtMode" id="inlineRadio2" value="Live" <?php if ($edit->mode == '1'): ?>checked='checked'<?php endif; ?>/> Live
                                </label>
                              </div>
                            </div>  
                          </div>   
                          <p>                       
                                                
                         <div class="row">
                            <div class="form-group {{ $errors->has('txtLogLevel') ? ' has-error' : '' }}">
                              <label class="col-md-3 control-label" for="business_phone_company">LOG LEVEL</label>
                              <div class="col-md-9">
                                <label class="radio-inline">
                                  <input type="radio" name="txtLogLevel" id="inlineRadio1" value="Debug" <?php if ($edit->loglevel == '0'): ?>checked='checked'<?php endif; ?>/> Debug
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="txtLogLevel" id="inlineRadio2" value="Fine" <?php if ($edit->loglevel == '1'): ?>checked='checked'<?php endif; ?> /> Fine
                                </label>
                              </div>
                            </div>  
                        </div> 
                        <p>
                         <div class="row">
                            <div class="form-group {{ $errors->has('txtCache') ? ' has-error' : '' }}">
                              <label class="col-md-3 control-label" for="business_phone_company">CACHE ENABLED</label>
                              <div class="col-md-9">
                                <label class="radio-inline">
                                  <input type="radio" name="txtCache" id="inlineRadio1" value="Sandbox" <?php if ($edit->cache == '0'): ?>checked='checked'<?php endif; ?>/> True
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="txtCache" id="inlineRadio2" value="Live" <?php if ($edit->cache == '1'): ?>checked='checked'<?php endif; ?>/> False
                                </label>
                              </div>
                            </div>  
                        </div> 
                        <p>
                        <div class="row">
                            <div class="form-group {{ $errors->has('txtLogEnable') ? ' has-error' : '' }}">
                              <label class="col-md-3 control-label" for="business_phone_company">LOG ENABLED</label>
                              <div class="col-md-9">
                                <label class="radio-inline">
                                  <input type="radio" name="txtLogEnable" value="True" <?php if ($edit->logenable == '0'): ?>checked='checked'<?php endif; ?>/> True
                                </label>
                                <label class="radio-inline">
                                  <input type="radio" name="txtLogEnable" value="False" <?php if ($edit->logenable == '1'): ?>checked='checked'<?php endif; ?>/> False
                                </label>
                              </div>
                            </div>  
                        </div> 
                        <p> 
                        <div class="row">
                        <div class="col-xs-12 text-center">
                          <div class="form-group">
                            <input class="btn btn-primary fa fa-floppy-o" type="submit" name="update" value="Update">                      
                          </div>
                        </div>
                      </div>
                      {{ Form::close() }}
                    </div>
                  </div>
              </div>
            </div>
          <!-- end: content -->
@endsection   
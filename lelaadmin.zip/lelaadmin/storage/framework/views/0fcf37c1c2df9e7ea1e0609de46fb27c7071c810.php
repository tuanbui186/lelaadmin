<?php $__env->startSection('content'); ?>
<!-- start: Content -->
            <div id="content">
               <div class="panel box-shadow-none content-header">
                  <div class="panel-body">
                    <div class="col-md-12">
                        <h3 class="animated fadeInLeft">User Management</h3>

                        <p class="animated fadeInDown">
                        </p>
                    </div>
                  </div>
              </div>
              <div class="col-md-12 top-20 padding-0">
                <div class="col-md-12">
                  <div class="panel">
                    <div class="panel-heading">
                    <h3> Lela Interpreter
                    
                    </h3>
                  </div>
                    <div class="panel-body">
                      <div class="responsive-table">
                      <table id="datatables-example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                              <thead>
                                <tr>
                                  <th>Interpreter ID</th>
                                  <th>User ID</th>
                                  <th>Email </th>
                                  <th>Display Name</th>
                                  <th>Language</th>
                                  <th>Active Code</th>
                                  <th>Is Active</th>
                                  <th>Status</th>   
                                  <th>IsApprove</th>                
                                  <th>Rating</th>   
                                </tr>
                              </thead>
                              <tbody>

                              <?php foreach($rate as $print): ?> 
                                                  
                                <tr>
                                  <td><?php echo e($print->Id); ?></td>
                                  <td><?php echo e($print->UserId); ?></td>
                                  <td><?php echo e($print->email); ?></td>
                                  <td><?php echo e($print->name); ?></td>
                                  <td>
                                  <?php foreach($lang as $l): ?>   
                                    <?php
                                      if ($print->LanguageId == $l->LangId)
                                      {
                                        echo $l->LangName;
                                      }
                                      ?>
                                  <?php endforeach; ?>
                                  </td>
                                  
                                  <td><?php echo e($print->ActiveCode); ?></td>
                                  <td>
                                  <?php
                                  if ($print->IsActive == 1) 
                                  {
                                  echo "X"; 
                                  }         
                                  ?>
                                  </td>
                                  <td>
                                  <?php
                                  if ($print->StatusId == 1)
                                  {
                                    echo "Online";
                                  }
                                  else if ($print->StatusId ==2)
                                  {
                                    echo "Offline";
                                  }
                                  else if ($print->StatusId == 3)
                                  {
                                    echo "Requesting";
                                  }
                                  else if ($print->StatusId == 4)
                                  {
                                    echo "Waiting";
                                  }
                                  else if ($print->StatusId == 5)
                                  {
                                    echo "Calling";
                                  }
                                  ?> 
                                  </td>
                                  <td>
                                  <?php
                                  if ($print->IsApprove == 1) 
                                  {
                                  echo "X"; 
                                  }         
                                  ?>
                                  </td>                                  
                                  <td>
                    
                                  </td>
                                </tr>
                                                            
                                <?php endforeach; ?>
                              </tbody>
                        </table>
                      </div>
                  </div>
                </div>
              </div>  
              </div>
            </div>
          <!-- end: content -->

<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
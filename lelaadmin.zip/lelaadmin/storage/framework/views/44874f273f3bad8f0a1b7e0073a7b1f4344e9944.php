<?php $__env->startSection('content'); ?>
<!-- start: Content -->
            <div id="content">
               <div class="panel box-shadow-none content-header">
                  <div class="panel-body">
                    <div class="col-md-12">
                        <h3 class="animated fadeInLeft">TRANSACTION DASHBOARD</h3>
                        <p class="animated fadeInDown">
                        </p>
                    </div>
                  </div>
              </div>
              <div class="col-md-12 top-20 padding-0">
                <div class="col-md-12">
                  <div class="panel">
                    <div class="panel-heading"><h3> Lasted Transaction</h3></div>
                    <div class="panel-body">
                      <div class="responsive-table">
                      <table id="datatables-example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                              <thead>
                                <tr>
                                  <th>Transaction ID</th>
                                  <th>Client</th>
                                  <th>Interpreter</th>
                                  <th>Duration</th>
                                  <th>Tip</th>
                                  <th>Total Money </th>
                                  <th>Category </th>
                                  <th>Is Cancel</th>
                                  <th>Create Date</th>
                                  <th>Status</th>
                                  <th>Target Language</th>
                                  <th>Money Translator</th>                          
                                </tr>
                              </thead>
                              <tbody>
                              <?php foreach($trans as $print): ?> 
                                <tr>
                                  <td><?php echo e($print->Id); ?></td>
                                  <td>
                                      <?php foreach($user as $u): ?>   
                                        <?php
                                          if ($print->UserSrc == $u->UserId)
                                          {
                                            echo $u->DisplayName;
                                          }  
                                        ?>
                                      <?php endforeach; ?>
                                  </td>
                                  <td>
                                      <?php foreach($user as $u): ?>   
                                        <?php
                                          if ($print->UserDes == $u->UserId)
                                          {
                                            echo $u->DisplayName;
                                          }  
                                        ?>
                                      <?php endforeach; ?>
                                  </td>

                                  <td><?php echo e($print->Duration); ?></td>
                                  <td><?php echo e($print->Tip); ?></td>
                                  <td><?php echo e($print->TotalMoney); ?></td>
                                  <td>
                                  <?php

                                  if($print->CategoryId ==1)
                                  {
                                      echo "Popular";
                                  }
                                  else if($print->CategoryId == 2)
                                  {
                                      echo  "Court";
                                  }
                                  else if ($print->CategoryId == 3)
                                  {
                                      echo "Medical";
                                  }
                                   ?>
                                  </td>                                                                                                  
                                  <td>
                                    <?php
                                    if ($print->IsCancel ==1)
                                    {
                                      echo "X";
                                    }
                                    ?>                                  
                                  </td>
                                  <td><?php echo e($print->CreateDate); ?></td>
                                  <td><?php echo e($print->Status); ?></td>
                                  <td><?php echo e($print->targetLangId); ?></td>
                                  <td><?php echo e($print->moneyTrans); ?></td>
                                </tr>
                                <?php endforeach; ?>
                              </tbody>
                        </table>
                      </div>
                  </div>
                </div>
              </div>  
              </div>
            </div>
          <!-- end: content -->

<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
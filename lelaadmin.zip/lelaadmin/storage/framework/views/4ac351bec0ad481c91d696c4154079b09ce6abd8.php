<?php $__env->startSection('content'); ?>
<!-- start: Content -->
            <div id="content">
               <div class="panel box-shadow-none content-header">
                  <div class="panel-body">
                    <div class="col-md-12">
                        <h3 class="animated fadeInLeft">Payment Management</h3>
                        <p class="animated fadeInDown">
                        </p>
                    </div>
                  </div>
              </div>
              <div class="col-md-12 top-20 padding-0">
                <div class="col-md-12">
                  <div class="panel">
                    <div class="panel-heading text-center"><img src="<?php echo e(url('public/lelatemplate/asset/img/cardpayment.jpg')); ?>" height="200" width="400" /></div>
                    <div class="panel-body">
                      <div class="responsive-table">
                      <table id="datatables-example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                              <thead>
                                <tr>
                                  <th>ID</th>
                                  <th>Name</th>
                                  <th>Status</th>
                                  <th>Edit</th>               
                                </tr>
                              </thead>
                              <tbody>
                              <?php foreach($paymana as $print): ?> 
                                <tr>
                                  <td><?php echo e($print->id); ?></td>
                                  <td><?php echo e($print->name); ?></td>                                                           
                                  <th><?php
                                  if ($print->status == 1)
                                  {
                                    echo "On";
                                  }
                                  else if($print->status == 0){
                                    echo "Off";
                                  }
                                  ?> </th>
                                  <td>
                                    <?php 
                                    if ($print->id == 1)
                                     {
                                    ?>
                                        <a class="btn btn-info btn-xs" href="<?php echo e(route('paypal.edit', 1)); ?>"><i class="fa fa-pencil fa-fw"></i> Edit</a>
                                   <?php } 
                                   else {
                                   ?>
                                        <a class="btn btn-info btn-xs" href="<?php echo e(route('stripe.edit', 1)); ?>"><i class="fa fa-pencil fa-fw"></i> Edit</a>
                                   <?php
                                      }
                                   ?>
                                  </td>
                                </tr>
                                <?php endforeach; ?>
                              </tbody>
                        </table>
                      </div>
                  </div>
                </div>
              </div>  
              </div>
            </div>
          <!-- end: content -->
<SCRIPT LANGUAGE="JavaScript">
    function confirmAction() {
      return confirm("Are you sure?");
    };

</SCRIPT>
<?php $__env->stopSection(); ?>   

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>